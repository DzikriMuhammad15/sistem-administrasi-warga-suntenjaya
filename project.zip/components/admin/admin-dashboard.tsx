"use client"

import { useState } from "react"
import { AdminSidebar } from "./admin-sidebar"
import { AdminHeader } from "./admin-header"
import { DashboardOverview } from "./dashboard-overview"
import { NewsManagement } from "./news-management"
import { EventsManagement } from "./events-management"
import { GalleryManagement } from "./gallery-management"
import { DocumentsManagement } from "./documents-management"
import { AnnouncementsManagement } from "./announcements-management"
import { VillageInfoManagement } from "./village-info-management"
import { HomepageContentManagement } from "./homepage-content-management"
import { SiteSettingsManagement } from "./site-settings-management"

export function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("overview")

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return <DashboardOverview />
      case "news":
        return <NewsManagement />
      case "events":
        return <EventsManagement />
      case "gallery":
        return <GalleryManagement />
      case "documents":
        return <DocumentsManagement />
      case "announcements":
        return <AnnouncementsManagement />
      case "village-info":
        return <VillageInfoManagement />
      case "homepage-content":
        return <HomepageContentManagement />
      case "site-settings":
        return <SiteSettingsManagement />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <AdminSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <AdminHeader />
        <main className="flex-1 overflow-y-auto">{renderContent()}</main>
      </div>
    </div>
  )
}
