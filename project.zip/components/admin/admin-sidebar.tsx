"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutDashboard,
  Newspaper,
  Calendar,
  Camera,
  FileText,
  Megaphone,
  Settings,
  Home,
  Globe,
  Users,
  Award,
} from "lucide-react"

interface AdminSidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

const menuItems = [
  {
    id: "overview",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    id: "homepage-content",
    label: "Homepage Content",
    icon: Home,
  },
  {
    id: "news",
    label: "News Articles",
    icon: Newspaper,
  },
  {
    id: "events",
    label: "Events",
    icon: Calendar,
  },
  {
    id: "gallery",
    label: "Gallery",
    icon: Camera,
  },
  {
    id: "village-officers",
    label: "Pemerintahan Desa",
    icon: Users,
  },
  {
    id: "village-heads",
    label: "Sejarah Kepala Desa",
    icon: Award,
  },
  {
    id: "documents",
    label: "Documents",
    icon: FileText,
  },
  {
    id: "announcements",
    label: "Announcements",
    icon: Megaphone,
  },
  {
    id: "village-info",
    label: "Village Info",
    icon: Settings,
  },
  {
    id: "site-settings",
    label: "Site Settings",
    icon: Globe,
  },
]

export function AdminSidebar({ activeSection, onSectionChange }: AdminSidebarProps) {
  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-900">Content Manager</h2>
        <p className="text-sm text-gray-600 mt-1">Desa Suntenjaya</p>
      </div>

      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                variant={activeSection === item.id ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 h-10",
                  activeSection === item.id
                    ? "bg-green-600 text-white hover:bg-green-700"
                    : "text-gray-700 hover:bg-gray-100",
                )}
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Button>
            )
          })}
        </nav>
      </ScrollArea>
    </div>
  )
}
